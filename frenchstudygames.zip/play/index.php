<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Study</title>
  <link rel="stylesheet" href="/style.css">
  <link rel="shortcut icon" href="images/play.ico" type="image/x-icon">
</head>
<body>
  <?php
    echo '<iframe src="https://replit.com/@MrHiTech/' . $_GET['game'] . '?lite=true&outputonly=1" frameborder="0" width="100%" height="550"></iframe><br>\'<a href="https://replit.com/@MrHiTech/' . $_GET['game'] . '?lite=true&outputonly=1\'">If the game isn\'t loading, click here.</a>';
  ?>
  
</body>
<script src="/play/script.js"></script>
<script src="/scripts/nocred.js"></script>
</html>