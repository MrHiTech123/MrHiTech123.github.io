<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta lang="en-us">
    <meta name="viewport" content="width=device-width">
    <meta name="author" content="MrHiTech"></meta>
    <meta name="keywords" content="french, study, games">
    <title>French Study Games</title>
    <link href="style.css" rel="stylesheet" type="text/css" />
    <link rel="shortcut icon" type="image/x-icon" href="/images/franceMap.ico">
    
  </head>
  <body class="main">
    <div id="banner" onclick="document.getElementById('bannersecret').innerHTML = 'You found a secret!';"></div>
    <div id="bannersecret"></div>
    <div id="darkmode"></div>
    <h1 id="aprilfools"></h1>
    <h1>Navigation</h1>
    <table>
    <tr>10th Grade:</tr>
    <tr>
        <table>
            <tr>
            <td><a class="adminlink" href="/#test1">Games for test 1</a></td>
            </tr>
            <tr>
            <td><a class="adminlink" href="/#test2">Games for test 2</a></td>
            </tr>
            <tr>
            <td><a class="adminlink" href="/#test3">Games for test 3</a></td>
            </tr>
            <tr>
            <td><a class="adminlink" href="/#test4">Games for test 4</a></td>
            </tr>
            <tr>
            <td><a class="adminlink" href="/#test5">Games for test 5</a></td>
            </tr>
            <tr>
            <td><a class="adminlink" href="/#test6">Games for test 6</a></td>
            </tr>
            <tr>
            <td><a class="adminlink" href="/#othergames">Other games</a></td>
            </tr>
            <?php
            $ipaddresses = file("scavengerhunt/enterassembledcode/ipaddresses.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
            if (in_array($_SERVER['REMOTE_ADDR'], $ipaddresses)) {
            echo "<tr><td><a class=\"adminlink\" href=\"/#admin\">Admin Tools</a></td></tr>";
            }
            ?>
        </table>
    </tr>



</table>
    <h1 class="bigger">Current games</h1>
    <h2>None! Have a great summer!</h2>
    <h3 class="joinmailinglist" onclick="window.location.href = '/mailinglist/join'">Join the mailing list here!</h3>
    <h3 class="joinmailinglist" onclick="window.location.href = '/chatroom'">Talk in the chatroom!</h3>
    <h1 class="bigger">Older games</h1>
    <h1 id="test1">Test 1 and misc. quizzes and programs</h1>
    <table> 
      <tr>
        <td><a class="imperepl" href="https://verbconjugator.mrhitech.repl.run">Conjugator of regular verbs</a></td>
        <td>My first program that I made to help with <br> French. Mostly  made redundant by the <a class="imperepl"  href="https://Verbconjugatortestwithaccents.MrHiTech.repl.run">er verb <br> conjugation quiz</a> and the <a class="imperepl" href="https://irverbconjugator.mrhitech.repl.run">ir verb conjugation <br> quiz</a></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://randompronoun.mrhitech.repl.run/">Random pronoun generator</a></td>
        <td><img src="/images/people.jpg" alt="pic of people" height="100" width="150"></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://Verbconjugatortestwithaccents.MrHiTech.repl.run">Er verb conjugation quiz</a></td>
        
      </tr>
      <tr>
        <td><a class="imperepl" href="https://frenchconditions.mrhitech.repl.run/">Quiz on conditions</a></td>
        
      </tr>
      <tr>
        <td><a class="imperepl" href="https://faireConjugationQuiz.MrHiTech.repl.run">Faire conjugation quiz</a></td>
        <td>Made redundant by the <a class="imperepl"  href="https://Sportsquiz.MrHiTech.repl.run">sports quiz</a>, but still <br> potentially useful if you only want to <br> practice faire</td>
      </tr>
    </table>
    <h1 id="test2">Test 2 review</h1>
    <table>
      <tr>
        <td><button onclick="document.getElementById('sike').innerHTML = 'Sorry, to do a quiz for  the partie orale, I\'d need to make AI, and I don\'t even know how to do that.</p>'">
      Quiz on partie orale
    </button></td>
      <td><div id="sike"></div></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://irverbconjugator.mrhitech.repl.run">Quiz on conjugation of ir verbs</a></td>
        <td></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://choresquizfaire.mrhitech.repl.run">Quiz on chores that use faire</a></td>
        <td><img src="/images/chores.jpg" alt="Image of people doing chores" width="50" height="50"></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://Sportsquiz.MrHiTech.repl.run">Quiz on sports (includes faire and forms of de)</a></td>
        <td><img title="Hi person on a computer, why are you on a computer? You can only type accent marks in this website on iPads!" src="/images/soccer_ball.jpg" alt="soccer_ball" width="50", height="50"></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://weatherfrenchquiz.mrhitech.repl.run">Quiz on weather</a>
        </td>
        <td><img src="/images/cloud.png" alt="" width="50" height="25"></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://Housequiz.MrHiTech.repl.run">Quiz on house rooms</a>
        </td>
        <td><img src="/images/house.jpg" alt="House picture" width="50" height="50"></td>
      </tr>
      <tr>
        <td>
          <a class="imperepl" href="https://Miscverbs.MrHiTech.repl.run">Miscellaneous verbs that were not in earlier <br> games but we do need to know for the test</a>
        </td>
        <td></td>
      </tr>
    </table>
    <h1 id="test3">Test 3 review</h1>
    <table>
      <tr>
        <td><a class="imperepl" href="https://reverbconjugation.mrhitech.repl.run">Re verb conjugation quiz</a></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://Negationsquiz.MrHiTech.repl.run">Négation quiz</a></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://OvergarmentsQuiz.MrHiTech.repl.run">Quiz on overgarments</a></td>
        <td><img src="/images/winter_clothes.jpg" alt="Winter clothes pic" width="50" height="33"></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://Maleclothesquiz.MrHiTech.repl.run">Quiz on male clothes</a></td>
        <td><img src="/images/clothesboy.jpg" alt="boyclothespic" width="50" height="50"></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://femaleclothesquiz.MrHiTech.repl.run">Quiz on female clothes</a></td>
        <td><img src="/images/clothesgirl.jpeg" alt="girlclothespic" width="50" height="50"></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://vaguein3rdperson.MrHiTech.repl.run">Quiz on using verbs with third-person pronouns</a></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://verbswithallpronouns.MrHiTech.repl.run">Quiz on using verbs with all pronouns</a></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://mettreconjugation.MrHiTech.repl.run">Mettre conjugation game</a></td>
      </tr>
    </table>
    <h1 id="test4">Test 4 review</h1>
    <table>
      <tr>
        <td><a class="imperepl" href="https://devoirconjugation.MrHiTech.repl.run">Devoir conjugation game</a></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://direconjugation.MrHiTech.repl.run">Dire conjugation game</a></td>
      </tr>
    </table>
    <h1 id="test5">Test 5 review</h1>
    <table>
      <tr>
        <td><a class="imperepl" href="https://fruitgame.MrHiTech.repl.run">Quiz on fruit</a></td>
        <td><img src="/images/fruit.png" alt="fruit" width="50" height="50"></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://veggiesgame.MrHiTech.repl.run">Quiz on vegetables</a></td>
        <td><img src="/images/veggies.jpg" alt="vegetables" width="50" height="50"></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://meatgame.MrHiTech.repl.run">Quiz on meat and poultry and fish.</a></td>
        <td><img src="/images/meat.png" alt="meat" width="50" height="50"></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://condimentsgame.MrHiTech.repl.run">Quiz on condiments.</a></td>
        <td><img src="/images/condiments.jpg" alt="fruit" width="50" height="50"></td>
      </tr>
      
      <tr>
        <td><a class="imperepl" href="https://miscfoods.MrHiTech.repl.run">Quiz on miscellaneous foods</a></td>
        <td><img src="/images/misc_foods.png" alt="cheese" width="50" height="50"></td>
      </tr>
      <tr>
        <td><a class="imperepl" href="https://pouvoirconjugation.MrHiTech.repl.run">Quiz on pouvoir</a></td>
        <td><img src="/images/judge.jpg" alt="judge" width="50" height="50"></td>
      </tr>
      <tr>
        <td>
        <a class="imperepl"  href="https://boire.MrHiTech.repl.run">Quiz on boire</a></td>
        <td><img src="/images/water.jpg" alt="glass of water" width="50" height="50"></td>
      </tr>
      <tr>
        <td><a href="https://articles.MrHiTech.repl.run" class="imperepl">Quiz on articles</a></td>
      </tr>
      <tr>
        <td><a href="https://foodsfortest5.MrHiTech.repl.run" class="imperepl">Quiz on the foods that will be on the test vocab</a></td>
      </tr>
      <tr>
        <td><a href="https://prendre.MrHiTech.repl.run" class="imperepl">Quiz on prendre</a></td>
      </tr>
    </table>
    <h1>Test 6 review</h1>
    <table id="test6">
      <tr>
        <td><a href="https://vouloirconjugation.MrHiTech.repl.run" class="imperepl">Quiz on vouloir</a></td>
      </tr>
      <tr>
        <td><a href="https://pasttense.MrHiTech.repl.run" class="imperepl">Quiz on past tense</a></td>
      </tr>
      <tr>
        <td><a href="https://venirconjugation.MrHiTech.repl.run" class="imperepl">Quiz on venir</a></td>
      </tr>
      <tr>
        <td><a href="https://irregular-past-tense.MrHiTech.repl.run" class="imperepl">Quiz on irregular past tense</a></td>
      </tr>
      <tr>
        <td><a href="https://etreconjugationpasttense.MrHiTech.repl.run" class="imperepl">Quiz on the conjugation of verbs that use être for past tense</a></td>
      </tr>
      <tr>
        <td><a href="https://etrevsavoir.MrHiTech.repl.run" class="imperepl">Quiz on which verbs use être and which use avoir for past tense.</a></td>
      </tr>
      <tr>
        <td><a href="https://drmrspvandertramp.MrHiTech.repl.run" class="imperepl">Quiz on Dr. Mrs. P. Vandertramp</a></td>
      </tr>
    </table>
    <h1 id="othergames">Other games</h1>
    <table id="othergamestable">
      <tr>
        <td><a href="totheguillotine">To the Guillotine!</a></td>
        <td>I made this for design engineering, <br> but it is technically a French game.</td>
      </tr>
      <tr>
        <td><a href="spotthefrenchsoldier">Spot the French Soldier</a></td>
        <td>Inspired by <a href="https://youtu.be/dHSQAEam2yc?t=206">this video</a>. No excuse <br> here, I'm just procrastinating.</td>
      </tr>
      <tr>
        <td><a href="roniskiadventure/interactive">Roni's Ski Adventure Game!</a></td>
        <td>Happy birthday Roni! <br> <button onclick="document.getElementById('roniexplanation').innerHTML = 'Because it was Roni\'s birthday, we replaced Vincent Dubois with him in the paragraph where he likes to ski. '">Explanation if you're in the other class</button></td>
        <td id="roniexplanation"></td>
      </tr>
      <tr>
        <td><a href="roniskiadventure/uninteractive">Roni's Ski Adventure Movie!</a></td>
        <td>Happy birthday Roni!</td>
      </tr>
      <tr>
        <td><a href="/l'huile-de-fromage">L'huile de fromage!</td>
      </tr>
      <tr>
        <td><a href="hebrewstudygames">Hebrew study games</a></td>
      </tr>
      
    </table>
    <h1>Don't forget to REVIEW</h1>
    <div id="study">
    </div>
    <div id="enteredcode"></div>
    <p>Get an IP log for your <a href="scavengerhunt/info">numerical code </a> <a href="scavengerhunt/enterassembledcode/">here</a> 
    </p>
    <?php
      $ipaddresses = file("scavengerhunt/enterassembledcode/ipaddresses.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
      if (in_array($_SERVER['REMOTE_ADDR'], $ipaddresses))
      {
        echo '<a href="https://repl.it/@MrHiTech/frenchstudygamesediting#index.html">View source code</a><br><a href="https://www.000webhost.com/members/website/list">Edit source code if you\'re me.</a><br><a href="https://docs.google.com/document/d/1BOCbokS4bC2ttQ_Xjj606uHxeKpU2fX16_W_ln8bi8Q/edit?usp=sharing">Write your name here to claim victory!</a><br><a href="/mailinglist/join/emails.txt">Mailing list doc</a><br>';
        $colors = array('aqua', 'red', 'orange', 'yellow', 'lime','green', 'blue', 'darkblue', 'blueviolet', 'purple', 'black', 'white');
        foreach ($colors as $color) {
          echo '<button style="background-color:' . $color . '"  onclick="document.body.style.background =\'' . $color . '\';">Turn background ' . $color . '</button> <button style="background-color:' . $color . '"  onclick="var headings = document.getElementsByTagName(\'h1\'); for (var i = 0; i < headings.length; i ++) {headings[i].style.color =\'' . $color . '\';}">Turn headings ' . $color . '</button> <button style="background-color:' . $color . '"  onclick="var tables = document.getElementsByTagName(\'table\'); for (var i = 0; i < tables.length; i ++) {tables[i].style.border = \'2px double ' . $color . '\';}var tables = document.getElementsByTagName(\'tr\'); for (var i = 0; i < tables.length; i ++) {tables[i].style.border =\'2px double ' . $color . '\';}var tables = document.getElementsByTagName(\'td\'); for (var i = 0; i < tables.length; i ++) {tables[i].style.border =\'2px double ' . $color . '\';}">Turn tables ' . $color . '</button> <button onclick="document.body.style.color = \''. $color . '\'; var links = document.getElementsByTagName(\'a\'); for (var i = 0; i < links.length; i ++) {links[i].style.color = \'' . $color . '\';} " style="background-color:' . $color . ';">Change other text ' . $color . '</button> <br> ';
        }
      }
      
    ?>
    <div id="admin"></div>
    <div id="test"></div>
  </body>
<script src="/scripts/moon.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/p5.js/1.1.9/p5.min.js"></script>
<script src="/scripts/frbanner.js"></script>
<script src="/scripts/review.js"></script>
</html>
<script src="/scripts/main_script.js"></script>
<script src="/scripts/nocred.js"></script>
